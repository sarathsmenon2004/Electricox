package com.example.electricox.COMMON;

public class Utility
{
    public static String ip="192.168.31.113";

    public static String SERVERUrl="http://"+ip.trim()+":8080/ElectricOx/Android/Electricoz_Server.jsp";

     //http://localhost:8080/Electricox_server/Android/electricox_serverController.jsp
     // http://localhost:8080/Electricox_server/Android/Electricoz_Server.jsp

     //http://localhost:8080/ElectricOx/Android/Electricoz_Server.jsp
}